# Pehchaan - The Identifier

<p align = "center"><img src="../Pictures/App Logo.png" width = 10%"></img></p>
    
## Presentation
<p align = "center"><img src="Slides/Slide-0001.jpg"></img></p>
<p align = "center"><img src="Slides/Slide-0002.jpg"></img></p>
<p align = "center"><img src="Slides/Slide-0003.jpg"></img></p>
<p align = "center"><img src="Slides/Slide-0004.jpg"></img></p>
<p align = "center"><img src="Slides/Slide-0005.jpg"></img></p>
<p align = "center"><img src="Slides/Slide-0006.jpg"></img></p>
<p align = "center"><img src="Slides/Slide-0007.jpg"></img></p>

## Project details
This project was developed as part of our final year project of B.Tech - Computer Science at Vellore Institute of Technology, Vellore. The group consisted of [Anshul Hedau](https://www.linkedin.com/in/anshul-hedau) and [Dheeraj Nair](https://www.linkedin.com/in/dheeraj1998).
