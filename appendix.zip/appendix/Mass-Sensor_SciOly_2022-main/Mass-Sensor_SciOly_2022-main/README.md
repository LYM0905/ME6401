# Mass-Sensor_SciOly_2022
Used for the Detector Building Event for Texas State Science Olympiad 2021
All code was uploaded and processed through an Arduino UNO.
Along with a voltage divider, a Force Sensitive Resistor was integrated into the circuitry.
To adjust the resistance from the FSR and determine the relationship to the Mass, testing was done using the voltage in and the known mass.
Many series of regression were performed to best determine a formula to output a mass from an input voltage

<img width="461" alt="image" src="https://github.com/ar1vm0ndal/Mass-Sensor_SciOly_2022/assets/146998218/36ab7ccf-f738-4960-81f1-6ca219d784d7">
